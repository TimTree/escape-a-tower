Thanks for playing Escape a Tower!

If you downloaded the game, you'll need to extract the ZIP file so the game can run properly. In Windows, simply click on Extract All. In OS X, the ZIP file should automatically be extracted upon opening the file.

After that, to play the game, all you have to do is open Escape a Tower.html. All the other files are assets that are called for while playing. Don't move around any of the files, or else the game won't work the way it should.

Enjoy!


COMPATIBLE BROWSERS
You'll need to enable Javascript and use one of the following browsers:

MINIMUM				RECOMMENDED
Internet Explorer 8		Internet Explorer 10+
Firefox 0.1			Firefox 3.5+
Chrome 0.2			Chrome 4+
Safari 3 (Mobile: iOS 3)	Safari 4+ (Mobile: iOS 6+)
Opera 7				Opera 11.50+
Netscape 7			Microsoft Edge

Recommended browsers offer the best visual effects and the ability to save your progress.


COPYRIGHT NOTICE
Escape a Tower is copyright (c) 2010-2016 Timothy Hsu. You have my permission to tinker around with the source code for personal use (after all, that's a good way to learn how to write HTML). All I ask is that you don't sell the game or distribute modified versions of the game without my approval. Otherwise...I don't want to say it...just be good, ok?


CONTACT INFO
To send feedback or bug reports about Escape a Tower, leave a comment at the following URL.

http://slideshowgames.blogspot.com/2011/08/escape-tower-more-info.html
